#!/usr/bin/env bash
# Non-invasive IOTA addon for the pinned original vps-dual.sh.
# The original installer, its state/config/keys and its subscription server are NOT edited.
set -Eeuo pipefail
umask 077

readonly UPSTREAM_COMMIT='b7bba12fb04d66daa750c1623bcbf250922b4f5b'
readonly UPSTREAM_URL="https://raw.githubusercontent.com/baibai131131/deploy_nodes/${UPSTREAM_COMMIT}/vps-dual.sh"
readonly BASE_DIR="${IOTA_BASE_DIR:-/etc/vps-dual}"
readonly BASE_PROFILE="${BASE_DIR}/subscriptions/clash-all.yaml"
readonly STATE_FILE="${BASE_DIR}/state.env"
readonly ADDON_DIR="${BASE_DIR}/iota"
readonly ADDON_PROFILE="${ADDON_DIR}/clash-iota.yaml"

say() { printf '[IOTA] %s\n' "$*"; }
err() { printf '[IOTA ERROR] %s\n' "$*" >&2; exit 1; }
need_root() { [[ "$(id -u)" == 0 ]] || err '請在 VPS 上以 root 身份執行。'; }
usage() {
  cat <<'EOF'
用法: bash vps-dual-iota.sh <命令>
  install         新 VPS：運行固定版本原始安裝器，然後產生 IOTA 專用配置
                  已安裝原版：不重裝、不重啟任何服務，只新增配置
  profile         僅產生新 IOTA 配置（存在時拒絕覆蓋）
  refresh-profile 備份舊 IOTA 配置，再從原始 clash-all.yaml 重新產生
  doctor          只讀檢查 VPS 網路、HY2 服務和 UDP 計數器
  remove-addon    僅移除本附加配置，不移除原本 vps-dual 安裝
  help            顯示本說明
注意：新配置不會自動加入原訂閱伺服器，也不會自動在 Mac 上啟用。
EOF
}

check_base() {
  [[ -s "$STATE_FILE" ]] || err "找不到原始安裝狀態：$STATE_FILE；請先使用 install。"
  [[ -s "$BASE_PROFILE" ]] || err "找不到原始訂閱配置：$BASE_PROFILE；未作任何修改。"
  # Ensure source format is the explicitly reviewed vps-dual template.
  grep -Fq '  - name: HY2' "$BASE_PROFILE" || err '原配置中找不到 HY2 節點。'
  grep -Fq '  - name: TCP-REALITY' "$BASE_PROFILE" || err '原配置中找不到 TCP-REALITY 節點。'
  grep -q '^proxy-groups:' "$BASE_PROFILE" || err '原配置中缺少 proxy-groups，不支援自動生成。'
  grep -q '^proxies:' "$BASE_PROFILE" || err '原配置中缺少 proxies，不支援自動生成。'
}

create_profile() {
  local mode="${1:-new}" tmp backup_stamp
  need_root
  check_base
  if [[ -e "$ADDON_PROFILE" && "$mode" == 'new' ]]; then
    say "附加配置已存在，為保護資料不覆蓋：$ADDON_PROFILE"
    return 0
  fi
  mkdir -p -m 700 "$ADDON_DIR"
  chmod 700 "$ADDON_DIR"
  tmp="$(mktemp "${ADDON_DIR}/.clash-iota.XXXXXX")"
  trap 'rm -f "${tmp:-}"' RETURN
  # Extract only the original header and its exact proxy declarations.
  # This preserves original generated credentials without printing them to stdout.
  if ! awk '/^proxy-groups:/ {found=1; exit} {print} END {if (!found) exit 23}' "$BASE_PROFILE" > "$tmp"; then
    err '讀取原配置失敗，沒有修改原文件。'
  fi
  # The generated profile is opt-in and static: never automatically change egress mid-run.
  cat >> "$tmp" <<'YAML'
# IOTA ADDON: separate fixed, manually selectable UDP and TCP egress.
# This profile covers ALL captured UDP/TCP on this Mac, not only IOTA.
# Use only on a dedicated machine or customize routing deliberately.
proxy-groups:
  - name: IOTA-UDP
    type: select
    proxies:
      - HY2
      - DIRECT
  - name: IOTA-TCP
    type: select
    proxies:
      - HY2
      - TCP-REALITY
      - DIRECT
rules:
  - NETWORK,UDP,IOTA-UDP
  - MATCH,IOTA-TCP
YAML
  # Preflight: no empty content, both egress groups and original proxies present.
  [[ -s "$tmp" ]] || err '生成的 IOTA 配置為空。'
  grep -q '^  - name: IOTA-UDP$' "$tmp" || err '生成 UDP 分流失敗。'
  grep -q '^  - name: IOTA-TCP$' "$tmp" || err '生成 TCP 分流失敗。'
  if [[ -e "$ADDON_PROFILE" ]]; then
    backup_stamp="$(date -u '+%Y%m%dT%H%M%SZ')"
    # Never overwrite an earlier backup.
    local backup_file="${ADDON_PROFILE}.backup-${backup_stamp}-$$"
    cp -p -- "$ADDON_PROFILE" "$backup_file"
    say "原附加配置已備份：$backup_file"
  fi
  chmod 600 "$tmp"
  mv -f -- "$tmp" "$ADDON_PROFILE"
  trap - RETURN
  say "已生成獨立 IOTA 配置：$ADDON_PROFILE"
  say '原版 clash-all.yaml、state.env、Xray、HY2、訂閱服務、IOTA 資料均未修改。'
  say '請用 scp/ssh 私下拷到 Mac，切勿將包含密鑰的 YAML 上傳公開 GitHub。'
}

install_base_if_needed() {
  local tmp
  need_root
  [[ -d /run/systemd/system ]] || err '需要 systemd Linux VPS（Ubuntu/Debian 等），不是 Mac。'
  if [[ -e "$STATE_FILE" ]]; then
    say '檢測到原版已安裝：跳過原版重裝，避免重啟和覆寫原有配置。'
    check_base
    return 0
  fi
  command -v curl >/dev/null 2>&1 || err '缺少 curl。'
  tmp="$(mktemp)"
  trap 'rm -f "${tmp:-}"' RETURN
  say "下載用戶指定的原始版本：${UPSTREAM_COMMIT}"
  curl -fsSL --retry 3 --connect-timeout 15 --max-time 120 \
    --proto '=https' --tlsv1.2 "$UPSTREAM_URL" -o "$tmp" || err '原始腳本下載失敗，未安裝。'
  grep -Fq 'readonly APP_NAME="vps-dual"' "$tmp" || err '原始腳本內容與預期不符，拒絕執行。'
  grep -Fq 'readonly STATE_FILE="${APP_DIR}/state.env"' "$tmp" || err '原始腳本檔案結構不符，拒絕執行。'
  bash -n "$tmp" || err '原始腳本 Bash 語法檢查未通過，拒絕執行。'
  say '開始運行原始安裝器 install。原安裝器可能安裝軟體、建立服務和防火牆規則。'
  bash "$tmp" install
  trap - RETURN
  rm -f "$tmp"
  check_base
}

# No secret content is printed. This command never changes sysctl/iptables/services.
doctor() {
  need_root
  command -v systemctl >/dev/null 2>&1 || err '需要 systemctl。'
  echo '=== IOTA VPS read-only doctor ==='
  date -u '+UTC: %Y-%m-%d %H:%M:%S'
  echo '=== baseline services ==='
  local service
  for service in vps-dual vps-dual-hy2 vps-dual-subscriptions; do
    printf '%-26s ' "${service}.service"
    systemctl is-active "${service}.service" 2>/dev/null || true
  done
  echo '=== UDP buffers ==='
  for k in net.core.rmem_max net.core.wmem_max; do
    printf '%s = ' "$k"
    sysctl -n "$k" 2>/dev/null || true
  done
  echo '=== UDP counters (cumulative since boot; use two snapshots to infer changes) ==='
  if command -v nstat >/dev/null 2>&1; then
    nstat -az 2>/dev/null | grep -E '^(Udp(InErrors|RcvbufErrors|SndbufErrors|NoPorts)|Udp6(InErrors|RcvbufErrors|SndbufErrors))([[:space:]]|$)' || true
  elif [[ -r /proc/net/snmp ]]; then
    grep '^Udp:' /proc/net/snmp || true
  fi
  echo '=== interface statistics ==='
  if command -v ip >/dev/null 2>&1; then
    ip -s -brief link 2>/dev/null | head -n 15 || true
  fi
  echo '=== app profile ==='
  if [[ -s "$ADDON_PROFILE" ]]; then echo 'IOTA profile: present (opt-in, Mac not changed)'; else echo 'IOTA profile: not present'; fi
  echo '=== caution ==='
  echo 'VPS UDP counters and services do NOT verify Mac->VPS->Iroh end-to-end connectivity.'
}

remove_addon() {
  need_root
  if [[ ! -e "$ADDON_PROFILE" ]]; then
    say '附加配置不存在，無需操作。'
    return 0
  fi
  # Preserve prior backup files even on addon removal; no directory recursive deletion.
  rm -f -- "$ADDON_PROFILE"
  say '只移除了 clash-iota.yaml；原版服務、金鑰、訂閱及備份均保持不變。'
}

case "${1:-help}" in
  install) install_base_if_needed; create_profile new ;;
  profile) create_profile new ;;
  refresh-profile) create_profile refresh ;;
  doctor) doctor ;;
  remove-addon) remove_addon ;;
  help|-h|--help) usage ;;
  *) usage; err "未知操作：$1" ;;
esac
