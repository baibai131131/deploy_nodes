#!/usr/bin/env bash
set -euo pipefail
DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TMP="$(mktemp -d)"
trap 'rm -rf "$TMP"' EXIT
mkdir -p "$TMP/subscriptions"
printf 'SAMPLE_STATE=1\n' >"$TMP/state.env"
cat >"$TMP/subscriptions/clash-all.yaml" <<'YAML'
mixed-port: 7897
mode: rule
proxies:
  - name: TCP-REALITY
    type: vless
    server: 192.0.2.1
    port: 443
    uuid: example-do-not-use
  - name: HY2
    type: hysteria2
    server: 192.0.2.1
    port: 8443
    password: local-test
proxy-groups:
  - name: PROXY
    type: select
    proxies:
      - HY2
rules:
  - MATCH,PROXY
YAML
cp "$TMP/subscriptions/clash-all.yaml" "$TMP/original-copy"
IOTA_BASE_DIR="$TMP" bash "$DIR/vps-dual-iota.sh" profile
test -s "$TMP/iota/clash-iota.yaml"
cmp "$TMP/original-copy" "$TMP/subscriptions/clash-all.yaml"

grep -q '^  - name: IOTA-TCP$' "$TMP/iota/clash-iota.yaml"
grep -q '^  - name: IOTA-UDP$' "$TMP/iota/clash-iota.yaml"
grep -q '^  - NETWORK,UDP,IOTA-UDP$' "$TMP/iota/clash-iota.yaml"
oldsum="$(sha256sum "$TMP/iota/clash-iota.yaml" | cut -d' ' -f1)"
IOTA_BASE_DIR="$TMP" bash "$DIR/vps-dual-iota.sh" profile
newsum="$(sha256sum "$TMP/iota/clash-iota.yaml" | cut -d' ' -f1)"
test "$oldsum" = "$newsum"
IOTA_BASE_DIR="$TMP" bash "$DIR/vps-dual-iota.sh" refresh-profile
compgen -G "$TMP/iota/clash-iota.yaml.backup-*" >/dev/null
cmp "$TMP/original-copy" "$TMP/subscriptions/clash-all.yaml"
IOTA_BASE_DIR="$TMP" bash "$DIR/vps-dual-iota.sh" remove-addon
test ! -f "$TMP/iota/clash-iota.yaml"
compgen -G "$TMP/iota/clash-iota.yaml.backup-*" >/dev/null
cmp "$TMP/original-copy" "$TMP/subscriptions/clash-all.yaml"
if python3 -c 'import yaml' >/dev/null 2>&1; then
  IOTA_BASE_DIR="$TMP" bash "$DIR/vps-dual-iota.sh" profile
  python3 - "$TMP/iota/clash-iota.yaml" <<'PY'
import sys,yaml
with open(sys.argv[1],encoding='utf8') as f: d=yaml.safe_load(f)
assert d['mode']=='rule'
assert [x['name'] for x in d['proxy-groups']] == ['IOTA-UDP','IOTA-TCP']
assert d['rules'] == ['NETWORK,UDP,IOTA-UDP','MATCH,IOTA-TCP']
assert any(x['name']=='HY2' for x in d['proxies'])
PY
fi
printf '0/10 ok\n'
cat >"$TMP/p2p-test.log" <<'EOF'
2026-11-03 13:00:21 | WARNING | Broadcast peer status: 0/10 ok, 10 unreachable in 5002ms
EOF
# Mac collector itself references ~/Library/Logs; test static analysis separately.
echo 'PASS: addon isolation, idempotency, backup, removal, YAML parse'
