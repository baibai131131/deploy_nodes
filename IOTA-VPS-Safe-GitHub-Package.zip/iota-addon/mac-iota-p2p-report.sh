#!/usr/bin/env bash
# macOS: read-only, secrets-free aggregate from local IOTA CLI logs.
# Does not invoke IOTA, Clash, network configuration or root permissions.
set -euo pipefail

LOG_DIR="$HOME/Library/Logs/IOTA Train at Home"
LAST=60
if [[ "${1:-}" == '--last' ]]; then
  LAST="${2:-60}"
  [[ "$LAST" =~ ^[1-9][0-9]*$ ]] || { echo 'Usage: bash mac-iota-p2p-report.sh [--last N]' >&2; exit 2; }
  (( LAST <= 3000 )) || { echo 'Max --last: 3000' >&2; exit 2; }
elif [[ "${1:-}" == '--help' || "${1:-}" == '-h' ]]; then
  echo 'Usage: bash mac-iota-p2p-report.sh [--last N]'; exit 0
elif [[ "$#" -gt 0 ]]; then
  echo 'Usage: bash mac-iota-p2p-report.sh [--last N]' >&2; exit 2
fi

DAY="$(date +%Y-%m-%d)"
files=()
for name in "$DAY-cli.old.log" "$DAY-cli.log"; do
  [[ -f "$LOG_DIR/$name" ]] && files+=("$LOG_DIR/$name")
done
if (( ${#files[@]} == 0 )); then
  echo "找不到當天 IOTA CLI 日誌：$LOG_DIR"
  exit 1
fi

# Only emit numeric aggregates; source logs can include tokens/hotkeys and stay private.
{
  grep -hF 'Broadcast peer status:' "${files[@]}" || true
} | tail -n "$LAST" | awk '
  /Broadcast peer status: [0-9]+\/[0-9]+ ok, [0-9]+ unreachable/ {
    line=$0
    sub(/^.*Broadcast peer status: /,"",line)
    split(line, parts, " ")
    split(parts[1], ok_total, "/")
    good=ok_total[1]+0; total=ok_total[2]+0
    if (total <= 0 || good > total) next
    n++; good_sum+=good; total_sum+=total
    if (total-good > 0) problem++
  }
  END {
    printf "IOTA P2P peer-status summary (last %d matching broadcasts)\n", n
    printf "  successes / targets: %d / %d\n", good_sum, total_sum
    if (total_sum > 0) printf "  observed response ratio: %.1f%%\n", 100*good_sum/total_sum
    else print "  no matching records"
    printf "  broadcasts with unreachable peers: %d\n", problem
    print "NOTE: counts include repeated peer targets. This is NOT training success rate."
  }'
