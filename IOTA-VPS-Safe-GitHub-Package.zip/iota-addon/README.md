# IOTA Mac M4 × VPS Stable Gateway（原版安裝器保留）

這是對原始 `vps-dual.sh` 的**非侵入式附加入口**，用途是讓本地 Mac mini M4 的 IOTA 客戶端可以選擇固定的 VPS HY2 網路出口，並將 Mihomo 的 UDP 與 TCP 流量分開觀測和手動選擇。

## 精確的原版來源

- 原倉庫：`baibai131131/deploy_nodes`
- 原腳本：`vps-dual.sh`
- 固定 commit：`b7bba12fb04d66daa750c1623bcbf250922b4f5b`
- 原始網址：`https://raw.githubusercontent.com/baibai131131/deploy_nodes/b7bba12fb04d66daa750c1623bcbf250922b4f5b/vps-dual.sh`

**不修改原本 `vps-dual.sh`、任何 IOTA 客戶端資料或 Mac Clash 設定。** 原版已包含 VLESS TCP REALITY、HY2、自己的服務和訂閱伺服器、HY2 BBR、`udpIdleTimeout: 60s` 和 UDP socket 緩衝上限優化。避免重複做沒有證據支持的全局 sysctl 改動。

## 包含的文件

- `vps-dual-iota.sh`：新 VPS 上先執行**固定版本原安裝器**，再額外生成獨立 IOTA Mihomo 配置；若已存在原版安裝狀態，就**跳過重裝和服務重啟**。
- `mac-iota-p2p-report.sh`：Mac 上只讀取當天的 IOTA 日誌，輸出小型數字摘要，不輸出 raw tokens、hotkeys 或模型資料。
- `tests/test-addon.sh`：本地假資料測試生成、備份、回退及原配置是否保持不變。

### 新 VPS 安裝（Ubuntu / Debian systemd）

先將本專案上傳到 GitHub 同一倉庫的 **`iota-addon/` 子目錄**，不要覆蓋根目錄的 `vps-dual.sh`、`README.md` 或 `.gitignore`。建議先用自己的電腦下載腳本檢查，再在新 VPS 上執行：

```bash
curl -fsSLo vps-dual-iota.sh \
  https://raw.githubusercontent.com/baibai131131/deploy_nodes/main/iota-addon/vps-dual-iota.sh
bash -n vps-dual-iota.sh
sudo bash vps-dual-iota.sh install
```

> 上方 `main` 地址只會在 `iota-addon/vps-dual-iota.sh` 真正上傳到該倉庫後有效。在上傳前不要執行這個不存在的連結。若你上傳到其他倉庫/分支，改成對應 URL。

如果已經裝好原版：

```bash
sudo bash vps-dual-iota.sh install
```

它會檢查 `/etc/vps-dual/state.env`，已安裝就**不重新執行原安裝器**。若是新 VPS 則下載**指定 commit** 的原版運行 `install`，安裝成功後才生成新配置。原版安裝仍會正常設立系統服務、端口和憑證；我們沒有修改它的安裝邏輯。必須允許 VPS 本地/雲安全組的 TCP REALITY、UDP HY2 端口，端口依原版配置而定。

### 將專用配置私下拷入 Mac

VPS 製作的配置在：

```text
/etc/vps-dual/iota/clash-iota.yaml
```

裡面包含 **真實代理密碼和指紋**，只使用 SSH/SCP 私下拷貝，例如在 **Mac 終端機**執行（根據自己 SSH 帳號／金鑰調整）：

```bash
scp root@你的VPS_IP:/etc/vps-dual/iota/clash-iota.yaml ~/Downloads/clash-iota.yaml
chmod 600 ~/Downloads/clash-iota.yaml
```

如果 VPS 關閉 root SSH，請使用你的普通 SSH 帳號通過安全途徑取回文件，不要把 `/etc/vps-dual/iota` 改成 world-readable。

將 `~/Downloads/clash-iota.yaml` **作為新配置導入 Clash Verge**；不要替換、刪除或更新現有 `clash-all.yaml`。先在空閒時段測試，確定外網可通後，才考慮讓 IOTA 使用這個新配置；要回退就切回舊的配置。

**非常重要：** Clash Verge 必須選擇 **規則（Rule）** 模式，否則 GLOBAL 會忽略下列 `rules`。既有的 TUN 模式以 Clash Verge UI 設定為準，匯入這個 YAML 不會自動打開 TUN。

### 新配置如何分流

```yaml
proxy-groups:
  - name: IOTA-UDP
    type: select
    proxies: [HY2, DIRECT]
  - name: IOTA-TCP
    type: select
    proxies: [HY2, TCP-REALITY, DIRECT]
rules:
  - NETWORK,UDP,IOTA-UDP
  - MATCH,IOTA-TCP
```

這是**傳輸協定層的分流**，不是宣稱能自動識別所有 IOTA 權重域名。`NETWORK,UDP` 命中被 TUN 捕捉的**所有 UDP**（可能包含 DNS、QUIC、其他程式和部分權重流量）；`MATCH` 命中其餘流量。它只適合專門運行 IOTA 的 Mac，或之後做更精確的域名／進程分流。**不能把 `IOTA-TCP` 等同所有 S3 權重流量，不能把 `IOTA-UDP` 等同所有 Iroh 流量。**

預設固定選 HY2，不用原版 `AUTO`/`FAILOVER`。選擇組不會根據短暫的 HTTP 延遲自動切換，降低在上傳途中切換出口的風險，但也意味著 VPS 真故障時需要人手回退。跨境 UDP/QUIC 仍可能因雙重隧道、MTU、丟包、NAT、遠端 Peer 或中繼負載而表現不佳；**不保證提升 P2P 或避免分片提交超時**。

### 診斷和回退

VPS：

```bash
sudo bash vps-dual-iota.sh doctor
sudo bash vps-dual-iota.sh profile
sudo bash vps-dual-iota.sh refresh-profile
sudo bash vps-dual-iota.sh remove-addon
```

`doctor` 不修改網路/服務，輸出 HY2 狀態及 UDP 累積計數器。比較兩次累計值的增量，不能憑一次累計值判定丟包；VPS 的 UDP 計數器也不能代表端到端 Iroh 成功率。

Mac：

```bash
bash mac-iota-p2p-report.sh --last 60
```

對照**同一台 Mac**、相近 Run/Layer 的直連 / 舊 HY2 / 新 HY2，至少觀察多個完整週期：peer-status 回應比例、5 秒連線超時、activation 是否有效傳送、權重上傳最慢分片與最終提交成功。不能以兩台不同寬帶／不同出口一次的瞬時 P2P 值判定根因。

如果新的 IOTA 配置影響訓練，**在 Run 空閒階段切回舊訂閱**，不必卸載 VPS，也不必更改原版服務。`remove-addon` 只刪本附加 YAML，保留附加配置的備份、原版訂閱與服務。

## 保證事項與限制

- 原版 `vps-dual.sh` **未修改**，GitHub 新檔案也獨立放在 `iota-addon/` 目錄；本專案在新 VPS 上調用釘住 commit 的原版，保留其安裝行為。
- 已有 `/etc/vps-dual/state.env` 的 VPS 不執行原版安裝，防止非預期重啟服務。
- 附加 YAML 是新檔案，不修改原版 `clash-all.yaml`、原版 `subscription_server.py`、`state.env`、Xray 或 Hysteria 設定。
- **未在你的真實 VPS 和 Mac M4 上實測**，無法保證 100% 安裝成功或 100% IOTA 穩定。先選一台新 VPS、單台 Mac 做 A/B 對照。
- 原版可能使用 HTTP 訂閱路徑（攜帶憑證）；新附加配置刻意**不加入公開訂閱伺服器**。請使用 SSH 私密傳送。
- 安裝前檢查原版腳本、確保雲端 VPS 有備份和 SSH 控制台。請勿將真實 `state.env`、`share.txt`、`clash-iota.yaml`、日誌或私鑰提交公開 GitHub。

## 為何不是直接在 VPS 修改 IOTA 權重／合併？

IOTA Train at Home 在 Mac M4 本地執行。VPS 只能改善**它所承載的網路路徑**，無法控制官方 Run 的分片合併進度、遠端 Peer 存活、服務端階段切換或已有 `CASVersionMismatch` 的內部協調狀態。VPS 的 sysctl 和 HY2 BBR 也不能直接調整 Mac/Mihomo 上的 Iroh QUIC 實作。
